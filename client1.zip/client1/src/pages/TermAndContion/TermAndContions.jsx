import React from 'react'

const TermAndContions = () => {
  return (
    <div>TermAndContions</div>
  )
}

export default TermAndContions