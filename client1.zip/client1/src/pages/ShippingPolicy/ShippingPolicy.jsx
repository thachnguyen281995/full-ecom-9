import React from 'react'

const ShippingPolicy = () => {
  return (
    <div>ShippingPolicy</div>
  )
}

export default ShippingPolicy