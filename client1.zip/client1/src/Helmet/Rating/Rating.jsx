import React, { useState } from 'react';
import { Rate } from 'antd';
import './styles.css';
const Rating = ({customSize}) => {
  return <Rate className='text-base'/>;
};

export default Rating;
